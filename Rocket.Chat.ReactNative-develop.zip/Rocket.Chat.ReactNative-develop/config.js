export default {
	BUGSNAG_API_KEY: ''
};
