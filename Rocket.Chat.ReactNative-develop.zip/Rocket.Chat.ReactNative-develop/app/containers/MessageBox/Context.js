import React from 'react';

const MessageboxContext = React.createContext();
export default MessageboxContext;
