export const DISCUSSION = 'discussion';
export const THREAD = 'thread';
