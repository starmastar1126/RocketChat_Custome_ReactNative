export default {
	keyboardShouldPersistTaps: 'always',
	keyboardDismissMode: 'interactive'
};
