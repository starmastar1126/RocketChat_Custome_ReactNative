export default {
	getModel: () => '',
	getReadableVersion: () => '',
	getBundleId: () => '',
	isTablet: () => false
};
