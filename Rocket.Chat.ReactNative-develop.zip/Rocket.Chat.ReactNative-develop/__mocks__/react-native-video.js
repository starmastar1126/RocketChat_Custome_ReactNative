export default () => 'View';
