export const initialConstants = null;
export const findBestAvailableLanguage = () => null;
