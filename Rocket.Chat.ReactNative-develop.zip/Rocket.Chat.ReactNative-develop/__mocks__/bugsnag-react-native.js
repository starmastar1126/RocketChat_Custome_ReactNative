export class Client { }

export default {
	bugsnag: () => '',
	leaveBreadcrumb: () => '',
	notify: () => '',
	loggerConfig: () => ''
};
