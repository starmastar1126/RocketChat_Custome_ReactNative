export class Rocketchat {}
export const settings = {};
