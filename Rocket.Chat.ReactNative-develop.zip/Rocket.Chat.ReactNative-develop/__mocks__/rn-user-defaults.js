export default {
	set: () => '',
	get: () => ''
};
