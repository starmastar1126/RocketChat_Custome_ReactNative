- Your Rocket.Chat Experimental app version: ####
- Your Rocket.Chat server version: ####
- Device (or Simulator) you're running with: ####

**The app isn't connecting to your server?**
Make sure your server supports WebSocket. These are the minimum requirements for Apache 2.4 and Nginx 1.3 or greater.
